"""Framework configuration constants."""

# How much gold the hero receives when picking up a heart
HEART_GOLD = 50
